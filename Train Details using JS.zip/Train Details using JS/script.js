function formatTrainInfo(train) {
  const html = `
    <div class="detail">
      <div class="intro">
        <span>${train.train_number}</span> <span>${train.train_name}</span>
        </div>
        <div class="way">
          <span class="from">${train.departure_station}</span>
          <span><i class='bx bxs-chevrons-right'></i></span>
          <span class="to">${train.arrival_station}</span>
        </div>
        <div class="time">
          <span class="dept">Departure at ${train.departure_time}</span>
          <span class="arrive">Arrival at ${train.arrival_time}</span>
        </div>
		    <div class="classes">
          ${train.available_classes.map(className => `
            <span class="${train.availability[className] === 'Available' ? 'avilable' : 'soldout'}">${className} <span class="price"><i class='bx bx-rupee'></i>${train.fare[className].split(' ')[1]}</span></span>
          `).join('')}
        </div>
      </div>
    `;
  return html;
}

async function fetctData(){
	fetch('db.json')
  .then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    return response.json();
  })
  .then(data => {
	  const trains = data.trains; 
		if (!trains) {
		  throw new Error('No trains data found');
		}
		const trainInfoDiv = document.getElementById('trainInfo');
		if (trainInfoDiv) {
      Object.values(trains).forEach(trainData => {
        const trainHtml = formatTrainInfo(trainData);
        trainInfoDiv.innerHTML += trainHtml;
      });
		} else {
		  throw new Error('trainInfo div not found');
		}
	})
	.catch(error => {
		console.error('There was a problem fetching the train data:', error);
	});
}

fetctData();
